import bcrypt
from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages

# Create your views here.
def index(request):
    return render(request, "index.html")

def register(request):
    errors = User.objects.registration_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect("/")
    else:
        hash_it_up = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            email=request.POST['email'],
            birth_date=request.POST['birth_date'],
            password=hash_it_up
        )
        request.session['uuid'] = new_user.id
    return redirect("/dashboard")

def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        user = User.objects.filter(email = request.POST['email'])
        request.session['uuid'] = user[0].id
        return redirect("/dashboard")

def dashboard(request):
    if "uuid" not in request.session:
        return redirect("/")
    context = {
        "users": User.objects.get(id = request.session['uuid'])
    }
    return render(request, "dashboard.html", context)

def logout(request):
    del request.session['uuid']
    return redirect('/')