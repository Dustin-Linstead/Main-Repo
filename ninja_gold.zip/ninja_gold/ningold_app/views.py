from django.shortcuts import render, redirect
import random

def index(request):
    if 'gold_counter' in request.session:
        request.session['gold_counter']
        request.session['activities']
    else:
        request.session['gold_counter'] = 0
        request.session['activities'] = " "
        request.session['location'] = ""
    print(request.session)
    
    return render(request, "index.html")

def process_money(request):
    if request.session['location'] == "farm":
        gold = random.randrange(10, 21)
        gold = round(gold)
        request.session['gold_counter'] += gold
        request.session['activities'] = f"You went to the farm and gained {gold} gold!"
    if request.session['location'] == "cave":
        gold = random.randrange(5, 11)
        gold = round(gold)
        request.session['gold_counter'] += gold
        request.session['activities'] = f"You went to the cave and gained {gold} gold!"
    if request.session['location'] == "house":
        gold = random.randrange(2, 6)
        gold = round(gold)
        request.session['gold_counter'] += gold
        request.session['activities'] = f"You went to the house and gained {gold} gold!"
    if request.session['location'] == "casino":
        gold = random.randrange(-50, 51) 
        gold = round(gold)
        request.session['gold_counter'] += gold
        if gold < 0:
            request.session['activities'] = f"You went to the casino and lost {gold} gold!"
        else:
            request.session['activities'] = f"You went to the casino and gained {gold} gold!"
    print(request.session['activities'])
    return redirect('/')

def farm(request):
    request.session['location'] = "farm"
    return redirect('/process_money')

def cave(request):
    request.session['location'] = "cave"
    return redirect('/process_money')

def house(request):
    request.session['location'] = "house"
    return redirect('/process_money')

def casino(request):
    request.session['location'] = "casino"
    return redirect('/process_money')

def delete(request):
    print("Reset Post Info..................................")
    del request.session['gold_counter']
    del request.session['activities']
    del request.session['location']
    return redirect('/')