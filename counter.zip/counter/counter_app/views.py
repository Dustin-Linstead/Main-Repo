from django.shortcuts import render, redirect

def index(request):
    if 'counter' in request.session:
        #session_counter = request.session['counter']
        request.session['counter'] += 1
    else:
        request.session['counter'] = 1
        
    print(request.session)
    
    return render(request, "index.html")


def destroy(request):
    print("Reset Post Info..................................")
    del request.session['counter']	# clears a specific key

    return redirect('/')