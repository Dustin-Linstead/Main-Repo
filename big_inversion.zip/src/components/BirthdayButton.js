import React, { Component } from "react";


export default class BirthdayButton extends Component{
    constructor(props){
        super(props);
        const { age } = this.props;
        this.state = {
            age: age
        };
    }
    BirthdayClick = () => {
        alert("Happy Birthday! You're a year closer to dying.");
        let older = this.state.age;
        this.setState({ age: older += 1 });
        console.log(older)
    }
    render = () => {
        return(
            <div>
                <p>{ this.state.age }</p>
                <button onClick={ this.BirthdayClick }>Happy Birthday!</button>
            </div>
        );
    }
}