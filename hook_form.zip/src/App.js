import './App.css';
import React, { useState } from "react"
import UserForm from './components/HookForm';
import Results from './components/Results'

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    Cpassword: ""
  });
  return (
    <div className="App">
      <UserForm inputs={state} setInputs={setState} />
      <Results data={state} />
    </div>
  );
}

export default App;
