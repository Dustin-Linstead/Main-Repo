import React, { useState } from 'react';


const UserForm = props => {
    const { inputs, setInputs } = props;

    const createUser = e => {
        e.preventDefault();
        setInputs({
            ...inputs,
            [e.target.name]: e.target.value
        });
    };
    return (
        <>
            <form onSubmit={createUser}>
                <div>
                    <label htmlFor="firstName">First Name: </label>
                    <input type="text" name="firstName" onChange={createUser} />
                </div>
                <div>
                    <label htmlFor="lastName">Last Name: </label>
                    <input type="text" name="lastName" onChange={createUser} />
                </div>
                <div>
                    <label htmlFor="email">Email Address: </label>
                    <input type="text" name="email" onChange={createUser} />
                </div>
                <div>
                    <label htmlFor="password">Password: </label>
                    <input type="text" name="password" onChange={createUser} />
                </div>
                <div>
                    <label htmlFor="Cpassword">Confirm Password: </label>
                    <input type="text" name="Cpassword" onChange={createUser} />
                </div>
            </form>
        </>
    );
};

export default UserForm;
