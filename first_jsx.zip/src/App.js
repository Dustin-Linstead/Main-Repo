import './App.css';

function App() {
  return (
    <>
      <h1>Hello, World!</h1>
      <h2>Things I need to do:</h2>
      <ul>
        <li>Learn React</li>
        <li>Take a Nap</li>
        <li>SuMmOn ThE oLd OnEs</li>
        <li>Order Food</li>
      </ul>
    </>
  );
}

export default App;
