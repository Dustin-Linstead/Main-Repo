import React from "react";
import './App.css';

import PersonCard from './components/PersonCard'


function App() {
  return (
    <div className="App">
      <PersonCard lastName = "Smith" firstName = "Joe" age = { 42 } hairColor = "Brown" />
      <PersonCard lastName = "Coleson" firstName = "Steve" age = { 56 } hairColor = "White"/>
      <PersonCard lastName = "Farnsworth" firstName = "Lilly" age = { 23 } hairColor = "Blonde"/>
      <PersonCard lastName = "Gates" firstName = "Amy" age = { 30 } hairColor = "Black"/>
    </div>
  );
}

export default App;
