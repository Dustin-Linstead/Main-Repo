from django.apps import AppConfig


class NingoldAppConfig(AppConfig):
    name = 'ningold_app'
