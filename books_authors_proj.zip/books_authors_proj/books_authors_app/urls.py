from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('authors', views.authors),
    path('books/create', views.create_book),
    path('authors/create', views.create_author),
    path('display_authors/<int:author_id>', views.display_authors),
    path('books/<int:book_id>', views.display_books),
    path('books/<int:book_id>/add_author', views.add_author),
    path('display_authors/<int:author_id>/add_book', views.add_book)
]