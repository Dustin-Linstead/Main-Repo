from django.apps import AppConfig


class TimeAppOneConfig(AppConfig):
    name = 'time_app_one'
